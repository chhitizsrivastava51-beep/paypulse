require('dotenv').config();
const express = require('express');
const path = require('path');

const {
  PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET, PAYPAL_WEBHOOK_ID, ANTHROPIC_API_KEY,
  PORT = 3000, AI_MODEL = 'claude-sonnet-5-5'
} = process.env;
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const PP = 'https://api-m.sandbox.paypal.com'; // sandbox only

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const events = [];        // in-memory store (swap for a DB in production)
const seen = new Set();   // idempotency: PayPal may retry/duplicate webhooks
const clients = new Set(); // SSE subscribers

// ---------- PayPal helpers ----------
async function ppToken() {
  const auth = Buffer.from(`${PAYPAL_CLIENT_ID}:${PAYPAL_CLIENT_SECRET}`).toString('base64');
  const r = await fetch(`${PP}/v1/oauth2/token`, {
    method: 'POST',
    headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=client_credentials'
  });
  if (!r.ok) throw new Error(`PayPal auth failed: ${r.status}`);
  return (await r.json()).access_token;
}

async function verifyWebhook(req) {
  const h = req.headers;
  const r = await fetch(`${PP}/v1/notifications/verify-webhook-signature`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${await ppToken()}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      auth_algo: h['paypal-auth-algo'],
      cert_url: h['paypal-cert-url'],
      transmission_id: h['paypal-transmission-id'],
      transmission_sig: h['paypal-transmission-sig'],
      transmission_time: h['paypal-transmission-time'],
      webhook_id: PAYPAL_WEBHOOK_ID,
      webhook_event: req.body
    })
  });
  const data = await r.json();
  return data.verification_status === 'SUCCESS';
}

// ---------- AI insights (Anthropic API) ----------
async function getInsight() {
  if (!ANTHROPIC_API_KEY || events.length === 0) return null;
  const summary = events.slice(0, 20).map(e =>
    `${e.time} | ${e.type} | ${e.amount ?? '-'} ${e.currency ?? ''}`).join('\n');
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json'
      },
      body: JSON.stringify({
        model: AI_MODEL,
        max_tokens: 300,
        system: 'You are a cash-flow assistant for freelancers. Given recent PayPal events, reply with 2-3 short plain-language insights and flag anything unusual (refunds, disputes, gaps). No preamble.',
        messages: [{ role: 'user', content: summary }]
      })
    });
    const data = await r.json();
    return data.content?.map(c => c.text || '').join('') || null;
  } catch (e) { console.error('AI error', e.message); return null; }
}

function broadcast(payload) {
  const msg = `data: ${JSON.stringify(payload)}\n\n`;
  clients.forEach(c => c.write(msg));
}

// ---------- Routes ----------
app.post('/webhook', async (req, res) => {
  try {
    if (!(await verifyWebhook(req))) return res.sendStatus(400);
  } catch (e) { console.error(e.message); return res.sendStatus(500); }

  const ev = req.body;
  if (seen.has(ev.id)) return res.sendStatus(200); // duplicate
  seen.add(ev.id);

  const res_ = ev.resource || {};
  const record = {
    id: ev.id,
    type: ev.event_type,
    time: ev.create_time,
    amount: res_.amount?.value ?? res_.gross_amount?.value ?? null,
    currency: res_.amount?.currency_code ?? res_.gross_amount?.currency_code ?? null
  };
  events.unshift(record);
  res.sendStatus(200);

  broadcast({ event: record });
  const insight = await getInsight();
  if (insight) broadcast({ insight });
});

app.get('/api/events', (_req, res) => res.json(events));

app.get('/api/stream', (req, res) => {
  res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
  res.flushHeaders();
  clients.add(res);
  req.on('close', () => clients.delete(res));
});

app.post('/api/insight', async (_req, res) => res.json({ insight: await getInsight() }));

// Create a sandbox order (Orders API); open the returned link with a sandbox buyer account
app.post('/api/create-order', async (req, res) => {
  try {
    const value = String(req.body?.amount || '25.00');
    const r = await fetch(`${PP}/v2/checkout/orders`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${await ppToken()}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        intent: 'CAPTURE',
        purchase_units: [{ amount: { currency_code: 'USD', value } }],
        payment_source: { paypal: { experience_context: {
          return_url: `${BASE_URL}/api/capture`, cancel_url: BASE_URL, user_action: 'PAY_NOW' } } }
      })
    });
    const order = await r.json();
    const approve = order.links?.find(l => ['approve', 'payer-action'].includes(l.rel))?.href;
    res.json({ id: order.id, approve });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PayPal redirects here after the buyer approves; we capture the payment
app.get('/api/capture', async (req, res) => {
  try {
    await fetch(`${PP}/v2/checkout/orders/${req.query.token}/capture`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${await ppToken()}`, 'Content-Type': 'application/json' }
    });
  } catch (e) { console.error(e.message); }
  res.redirect('/'); // webhook PAYMENT.CAPTURE.COMPLETED will update the dashboard
});

app.listen(PORT, () => console.log(`PayPulse running at ${BASE_URL}`));
