# PayPulse

Real-time PayPal payment tracking with AI-generated cash-flow insights, built for the PayPal hackathon.

Freelancers and small businesses often learn about payments, refunds, and disputes hours late. PayPulse receives PayPal webhooks the moment they happen, shows them on a live dashboard, and uses an AI model to turn recent activity into plain-language insights.

## How it uses PayPal (sandbox)
- **Webhooks:** `PAYMENT.CAPTURE.COMPLETED`, refund, and dispute events are received at `/webhook`, signature-verified through PayPal's `verify-webhook-signature` API, and de-duplicated by event ID.
- **Orders API (v2):** Creates and captures sandbox payments (`/api/create-order`, `/api/capture`) so payments can be generated live in the demo.
- **Sandbox accounts:** Business and personal test accounts simulate full payment flows with no real money.

## How it uses AI
- **Claude (Anthropic Messages API):** After each verified event, the last 20 events are sent to Claude, which returns short insights and flags anything unusual (refunds, disputes, gaps). The result is pushed to the dashboard in real time.

## Other tools and technologies
- Node.js 18+ and Express
- Server-Sent Events for live dashboard updates
- Plain HTML/CSS/JS frontend
- ngrok (local webhook tunnel for testing)
- Sponsor integrations: none

## Setup
1. **Clone and install**
   ```bash
   git clone https://github.com/YOUR-USERNAME/paypulse.git
   cd paypulse
   npm install
   ```
2. **Create a PayPal sandbox app** at https://developer.paypal.com > Apps & Credentials (Sandbox). Copy the Client ID and Secret.
3. **Configure environment**
   ```bash
   cp .env.example .env
   ```
   Fill in `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET`, and `ANTHROPIC_API_KEY`.
4. **Start the app**
   ```bash
   npm start
   ```
5. **Expose it for webhooks**
   ```bash
   ngrok http 3000
   ```
   Set `BASE_URL` in `.env` to the ngrok https URL and restart.
6. **Register the webhook** in your sandbox app: URL `https://YOUR-NGROK-URL/webhook`, events `Payment capture completed`, `Payment capture refunded`, and the dispute events. Copy the **Webhook ID** into `PAYPAL_WEBHOOK_ID` in `.env` and restart.
7. **Try it:** open `http://localhost:3000`, click **Create $25 sandbox payment**, approve with a sandbox personal account, and watch the dashboard update.

## Project structure
```
paypulse/
├── server.js        # Express server: webhooks, Orders API, AI insights, SSE
├── public/index.html# Live dashboard
├── .env.example     # Required environment variables (no secrets)
├── package.json
├── LICENSE          # MIT
└── README.md
```

## Limitations and next steps
- Events are stored in memory; use a database for production.
- Multi-currency support, cash-flow forecasting, and accounting integrations (e.g. QuickBooks).

## License
MIT. See [LICENSE](LICENSE).
